<?php include 'db.php'; ?>

<?php
// Create / Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? '';
    $name = $_POST['name'];
    $type = $_POST['type'];
    $desc = $_POST['description'];
    $lat = $_POST['latitude'];
    $lng = $_POST['longitude'];
    $reported_by = $_POST['reported_by'];

    if ($id) {
        $stmt = $conn->prepare("UPDATE foodtrucks SET name=?, type=?, description=?, latitude=?, longitude=?, reported_by=? WHERE id=?");
        $stmt->bind_param("ssssssi", $name, $type, $desc, $lat, $lng, $reported_by, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO foodtrucks (name, type, description, latitude, longitude, reported_by) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $type, $desc, $lat, $lng, $reported_by);
    }

    $stmt->execute();
    header("Location: admin.php");
    exit();
}

// DELETE
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM foodtrucks WHERE id={$_GET['delete']}");
    header("Location: admin.php");
    exit();
}

// EDIT
$editData = null;
if (isset($_GET['edit'])) {
    $res = $conn->query("SELECT * FROM foodtrucks WHERE id={$_GET['edit']}");
    $editData = $res->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Food Truck Admin</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
  <h1>Food Truck Admin Dashboard</h1>
</header>

<main>
  <!-- Summary Cards -->
  <section class="stats flex">
    <div class="card">
      <h3>Total Food Trucks</h3>
      <p><?= $conn->query("SELECT COUNT(*) AS total FROM foodtrucks")->fetch_assoc()['total'] ?></p>
    </div>

    <div class="card">
      <h3>Unique Reporters</h3>
      <p><?= $conn->query("SELECT COUNT(DISTINCT reported_by) AS total FROM foodtrucks")->fetch_assoc()['total'] ?></p>
    </div>

    <div class="card">
      <h3>Last Reported Time</h3>
      <p>
        <?php
        $last = $conn->query("SELECT MAX(created_at) AS latest FROM foodtrucks")->fetch_assoc();
        echo $last['latest'] ? date("d M Y, h:i A", strtotime($last['latest'])) : "N/A";
        ?>
      </p>
    </div>
  </section>

  <!-- Flex container for Form and Table -->
  <div class="main-flex">
    <!-- Form Section -->
    <section class="form-section">
      <h2><?= $editData ? "Edit" : "Add New" ?> Food Truck</h2>
      <form method="POST">
        <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">

        <label>Name</label>
        <input type="text" name="name" value="<?= $editData['name'] ?? '' ?>" required>

        <label>Type</label>
        <select name="type" required>
          <?php
          $types = ['Breakfast', 'Dessert', 'BBQ', 'Coffee', 'Noodles', 'Burgers', 'Fusion', 'Ice Cream', 'Vegan', 'Drinks'];
          $selected = $editData['type'] ?? '';
          foreach ($types as $type) {
              $isSelected = ($selected === $type) ? 'selected' : '';
              echo "<option value=\"$type\" $isSelected>$type</option>";
          }
          ?>
        </select>

        <label>Description</label>
        <textarea name="description" rows="3" required><?= $editData['description'] ?? '' ?></textarea>

        <div class="flex">
          <div class="half">
            <label>Latitude</label>
            <input type="text" name="latitude" value="<?= $editData['latitude'] ?? '' ?>" required>
          </div>
          <div class="half">
            <label>Longitude</label>
            <input type="text" name="longitude" value="<?= $editData['longitude'] ?? '' ?>" required>
          </div>
        </div>

        <label>Reported By</label>
        <input type="text" name="reported_by" value="<?= $editData['reported_by'] ?? '' ?>" required>

        <button type="submit"><?= $editData ? 'Update' : 'Add' ?> Truck</button>
      </form>
    </section>

    <!-- Table Section -->
    <section class="table-section">
      <h2>Food Truck List</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Description</th>
            <th>Coordinates</th>
            <th>Reported By</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $data = $conn->query("SELECT * FROM foodtrucks ORDER BY created_at DESC");
          while ($row = $data->fetch_assoc()) {
              echo "<tr>
                  <td>{$row['name']}</td>
                  <td>{$row['type']}</td>
                  <td>{$row['description']}</td>
                  <td>{$row['latitude']}, {$row['longitude']}</td>
                  <td>{$row['reported_by']}</td>
                  <td>
                    <a href='admin.php?edit={$row['id']}' class='btn edit-btn'>Edit</a>
                    <a href='admin.php?delete={$row['id']}' class='btn delete-btn' onclick='return confirmDelete()'>Delete</a>
                  </td>
              </tr>";
          }
          ?>
        </tbody>
      </table>
    </section>
  </div>
</main>

<script>
function confirmDelete() {
  return confirm("Are you sure you want to delete this food truck?");
}
</script>
</body>
</html>
