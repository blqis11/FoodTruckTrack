<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    $name = $_POST['name'];
    $type = $_POST['type'];
    $desc = $_POST['description'];
    $lat = $_POST['latitude'];
    $lng = $_POST['longitude'];
    $reported_by = $_POST['reported_by'];

    $stmt = $conn->prepare("INSERT INTO foodtrucks (name, type, description, latitude, longitude, reported_by) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $type, $desc, $lat, $lng, $reported_by);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }
}
?>
