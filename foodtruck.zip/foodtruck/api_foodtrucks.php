<?php
header("Content-Type: application/json");

// Include your database connection
include 'db.php';


$sql = "SELECT * FROM foodtrucks 
       WHERE latitude BETWEEN 0.85 AND 7.50
  AND longitude BETWEEN 99.60 AND 119.30
        ORDER BY created_at DESC";

$result = $conn->query($sql);

// Prepare result
$trucks = [];

while ($row = $result->fetch_assoc()) {
    $trucks[] = [
        "id" => $row['id'],
        "name" => $row['name'],
        "type" => $row['type'],
        "description" => $row['description'],
        "latitude" => (float)$row['latitude'],
        "longitude" => (float)$row['longitude'],
        "reported_by" => $row['reported_by'],
        "created_at" => $row['created_at']
    ];
}

// Output JSON
echo json_encode($trucks);
