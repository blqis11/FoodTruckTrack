-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2025 at 07:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodtruckdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `foodtrucks`
--

CREATE TABLE `foodtrucks` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `reported_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foodtrucks`
--

INSERT INTO `foodtrucks` (`id`, `name`, `type`, `description`, `latitude`, `longitude`, `reported_by`, `created_at`) VALUES
(5, 'KL Burger Express', 'Burgers', 'Juicy gourmet burgers on wheels', 3.139, 101.68, 'Amir', '2025-07-15 08:28:08'),
(6, 'Nasi Lemak Legend', 'Breakfast', 'Classic nasi lemak with spicy sambal', 3.1412, 101.6931, 'Aina', '2025-07-15 08:28:55'),
(7, 'Kueh Mueh Manis', 'Dessert', 'Assorted traditional Malay sweets', 3.1275, 101.6534, 'Hafizah', '2025-07-15 08:29:20'),
(8, 'Kopi Kaw Kaw', 'Coffee', 'Strong local brews with modern twist', 3.1526, 101.7037, 'Faiz', '2025-07-15 08:29:42'),
(9, 'Satay Santai', 'BBQ', '	Charcoal-grilled satay, beef & chicken', 3.1132, 101.6759, 'Zulaikha', '2025-07-15 08:30:03'),
(10, 'Mee Goreng Mamak', 'Noodles', 'Fried noodles with egg & seafood', 3.2044, 101.7309, 'Izzat', '2025-07-15 08:30:33'),
(11, 'Fusion Rasa', 'Fusion', 'Malay-Western fusion rice and wraps', 3.0706, 101.6074, 'Alya', '2025-07-15 08:30:58'),
(12, 'Ais Krim Kelapa', 'Ice Cream', 'Coconut-based ice cream and treats', 3.187, 101.7123, 'Nurul', '2025-07-15 08:31:31'),
(13, 'Vegan On Wheels', 'Vegan', '	Plant-based burgers and wraps', 3.1248, 101.6842, 'Sara', '2025-07-15 08:32:00'),
(22, 'Kopi Gantung ', 'Coffee', 'Premium Coffee', 6.4333, 100.2, 'Nurul izzah', '2025-07-16 16:26:52'),
(23, 'Churos', 'Dessert', 'premium churos', 6.4, 100.1333, 'fatin', '2025-07-16 16:36:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `foodtrucks`
--
ALTER TABLE `foodtrucks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `foodtrucks`
--
ALTER TABLE `foodtrucks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
